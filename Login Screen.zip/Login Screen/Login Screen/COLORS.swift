//
//  COLORS.swift
//  Login Screen
//
//  Created by Hence4th on 19/01/18.
//  Copyright © 2018 Hence4th. All rights reserved.
//

import Foundation


enum COLORS : Int{
    case THEMECOLOR = 0x4BB0E4,
    DARKBLUE = 0x0976AE,
    LIGHTGRAY = 0xDDDDDD,
    BGCOLOR = 0xDBEFF9
}
