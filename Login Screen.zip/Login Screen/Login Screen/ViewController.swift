//
//  ViewController.swift
//  Login Screen
//
//  Created by Hence4th on 19/01/18.
//  Copyright © 2018 Hence4th. All rights reserved.
//

import UIKit

class ViewController: UIViewController,UITextFieldDelegate {

    @IBOutlet weak var contraintTopLogo: NSLayoutConstraint!
    
    @IBOutlet weak var BTNSGN: UIButton!
    
    @IBOutlet weak var btngl: UIButton!
    
    @IBOutlet weak var vw1: UIView!
    @IBOutlet weak var lblcnt: UILabel!
    @IBOutlet weak var btnfb: UIButton!
    @IBOutlet weak var btnfrgt: UIButton!
    @IBOutlet weak var btnlogin: UIButton!
    @IBOutlet weak var tfPassword: UITextField!
    @IBOutlet weak var tfEmail: UITextField!
    @IBOutlet weak var imgv: UIImageView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = UIColor(netHex: COLORS.THEMECOLOR.rawValue)
        setimage(tfEmail, image1: #imageLiteral(resourceName: "ic_envelope"))
        setimage(tfPassword, image1: #imageLiteral(resourceName: "ic_key"))
        btnlogin.backgroundColor = UIColor(netHex: COLORS.DARKBLUE.rawValue)
        btnfrgt.layer.cornerRadius = 5
        btnfb.layer.cornerRadius = 5
        btngl.layer.cornerRadius = 5
        btnlogin.layer.cornerRadius = 5
        btnlogin.titleLabel?.font = UIFont.boldSystemFont(ofSize: 18)
        BTNSGN.titleLabel?.font = UIFont.boldSystemFont(ofSize: 18)
        vw1.layer.cornerRadius = 5
        let attributedString = NSAttributedString(string: " Don't Have an Account? ", attributes: [NSForegroundColorAttributeName : UIColor.white])
       let selectedattribute = NSAttributedString(string: "SIGN UP" , attributes : [NSForegroundColorAttributeName : UIColor(netHex: COLORS.DARKBLUE.rawValue)])
        
        let btnTitle : NSMutableAttributedString = NSMutableAttributedString(attributedString: attributedString)
        btnTitle.append(selectedattribute)
        
        BTNSGN.setAttributedTitle(btnTitle, for: UIControlState.normal)
        let tap = UITapGestureRecognizer(target: self, action: #selector(self.handleTap(_:)))
        
        view.addGestureRecognizer(tap)
        
        btnlogin.addTarget(self, action:#selector(btnActNext(_:)), for: .touchUpInside)
        
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        btnlogin.alpha = 0 
        btnfrgt.alpha = 0
        btnfb.alpha = 0
        lblcnt.alpha = 0
        btngl.alpha = 0
        BTNSGN.alpha = 0
        vw1.alpha = 0
    }
    
    override func viewDidAppear(_ animated: Bool) {
        self.contraintTopLogo.constant = view.frame.midY -  self.imgv.frame.height/2
        self.view.layoutIfNeeded()
        
        DispatchQueue.main.asyncAfter(deadline: DispatchTime.now()+0.2) {
            self.contraintTopLogo.constant = self.view.frame.height/4 -  self.imgv.frame.height/2
            UIView.animate(withDuration: 2.0, delay: 0.5, options: UIViewAnimationOptions.curveEaseInOut, animations: {
                self.view.layoutIfNeeded()
            }) { (Bool) in
                UIView.animate(withDuration: 4.0, animations: {
                    self.tfEmail.alpha = 1
                    self.tfPassword.alpha = 1
                    self.btnlogin.alpha = 1 
                    self.btnfrgt.alpha = 1
                    self.btnfb.alpha = 1
                    self.lblcnt.alpha = 1
                    self.btngl.alpha = 1
                    self.BTNSGN.alpha = 1
                    self.vw1.alpha = 1
                }
                
            )}
        }
        
        
        
        
        
        
    }
    func setimage(_ tf: UITextField , image1: UIImage){
        
        let imageview = UIImageView(frame: CGRect(x: 0, y: 0, width: tf.frame.height, height: tf.frame.height))
        imageview.image = image1
        imageview.contentMode = .center
        tf.leftViewMode = .always
        tf.leftView = imageview
    }
    func alertShow(_ title: String, message: String) -> UIViewController{
        let alertController = UIAlertController(title: title, message: message, preferredStyle: .alert)
        
        
        let defaultAction = UIAlertAction(title: "Close", style: .cancel, handler: { (action) -> Void in })
        
        
        alertController.addAction(defaultAction)
        
        return alertController
        
        //    present(alertController, animated: true, completion: nil)
    }
    func isValidEmailAddress(emailAddressString: String) -> Bool {
        
        var returnValue = true
        let emailRegEx = "[A-Z0-9a-z.-_]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,3}"
        
        do {
            let regex = try NSRegularExpression(pattern: emailRegEx)
            let nsString = emailAddressString as NSString
            let results = regex.matches(in: emailAddressString, range: NSRange(location: 0, length: nsString.length))
            
            if results.count == 0
            {
                returnValue = false
            }
            
        } catch let error as NSError {
            print("invalid regex: \(error.localizedDescription)")
            returnValue = false
        }
        
        return  returnValue
    }
    func handleTap(_ sender: UITapGestureRecognizer) {
        
        self.view.endEditing(true)    
    }
    
        func textFieldShouldReturn(_ textField: UITextField) -> Bool {
            switch textField {
            case tfEmail:
            tfPassword.becomeFirstResponder()
                        default:
                textField.resignFirstResponder()
            }
            return true
        }
    
    func btnActNext(_ sender: UIButton){
       
            if tfEmail.text == "" {
            let alert = alertShow("ERROR", message: "Email field can not be empty")
            self.present(alert, animated: true, completion: nil)
            } else if isValidEmailAddress(emailAddressString:  tfEmail.text!) {
            let alert = alertShow("ERROR", message: "Invalid Email")
            self.present(alert, animated: true, completion: nil)
        }else if tfPassword.text == "" {
            let alert = alertShow("ERROR", message: "Password field can not be empty")
                self.present(alert, animated: true, completion: nil)}}
    
}
